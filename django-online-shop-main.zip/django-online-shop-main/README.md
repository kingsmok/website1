# Online shop API

API of the Online Shop using Django Framework

### API Actions

- [x] Home/About/Shop/Contact/Cart pages
- [x] Sidebar and footer with contact_info/number/categories
- [x] Login
- [x] Create Account
- [x] Categories by brands/sections/type/male
- [x] Single item pages with related products
- [x] Comments with rating for every product
- [x] Cart with stuff/quantity/price
- [x] Create order with final price
